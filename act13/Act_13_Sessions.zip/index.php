<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Creando la sesión</h1>

    <form action="panelControl.php" method="post">
        <label for="nombre">Nombres:</label>
        <br> <br>
        <input type="text" id="nombre" name="nombre" required></input>
        <br> <br>
        <button type="submit">Crear Sesión</button>
    </form>
</body>
</html>