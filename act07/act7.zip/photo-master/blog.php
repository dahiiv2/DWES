<?php
    require 'views/blog.view.php';